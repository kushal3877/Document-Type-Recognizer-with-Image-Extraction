import pytesseract
from PIL import Image
import fitz  # PyMuPDF
import docx
import pandas as pd
import tempfile

def extract_text_from_file(file):
    if file.type in ["image/jpeg", "image/png", "image/jpg"]:
        image = Image.open(file)
        return pytesseract.image_to_string(image)
    elif file.type == "application/pdf":
        text = ""
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(file.read())
            doc = fitz.open(tmp.name)
            for page in doc:
                text += page.get_text()
        return text
    elif file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        text = ""
        with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
            tmp.write(file.read())
            doc = docx.Document(tmp.name)
            for para in doc.paragraphs:
                text += para.text + "\n"
        return text
    elif file.type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        with tempfile.NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
            tmp.write(file.read())
            df = pd.read_excel(tmp.name)
        return "\n".join(df.astype(str).apply(lambda x: ' '.join(x), axis=1))
    else:
        return ""


import io
import zipfile
import docx
import openpyxl
from PIL import Image
import fitz  # PyMuPDF

def extract_images_from_file(file):
    images = []
    if file.type == "application/pdf":
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(file.read())
            doc = fitz.open(tmp.name)
            for page_index in range(len(doc)):
                for img_index, img in enumerate(doc.get_page_images(page_index)):
                    xref = img[0]
                    base_image = doc.extract_image(xref)
                    image_bytes = base_image["image"]
                    images.append(Image.open(io.BytesIO(image_bytes)))
    elif file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
        with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as tmp:
            tmp.write(file.read())
            doc = docx.Document(tmp.name)
            for rel in doc.part._rels:
                rel = doc.part._rels[rel]
                if "image" in rel.target_ref:
                    image_data = rel.target_part.blob
                    images.append(Image.open(io.BytesIO(image_data)))
    elif file.type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
        # Excel usually does not embed images in a simple way
        pass  # For simplicity, skip Excel image extraction
    return images


import zipfile
def zip_images(images):
    import io
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zip_file:
        for i, img in enumerate(images):
            img_byte_arr = io.BytesIO()
            img.save(img_byte_arr, format='PNG')
            zip_file.writestr(f"image_{i+1}.png", img_byte_arr.getvalue())
    zip_buffer.seek(0)
    return zip_buffer


# Translation support using googletrans
from googletrans import Translator

def translate_text(text, dest_lang='hi'):
    try:
        translator = Translator()
        translated = translator.translate(text, dest=dest_lang)
        return translated.text
    except Exception as e:
        return f"[Translation Error]: {str(e)}"



# Multilingual Translation (Hindi + Gujarati) using googletrans
from googletrans import Translator

def translate_text_multilang(text, lang='hi'):
    try:
        translator = Translator()
        translated = translator.translate(text, dest=lang)
        return translated.text
    except Exception as e:
        return f"[Translation Error: {str(e)}]"
