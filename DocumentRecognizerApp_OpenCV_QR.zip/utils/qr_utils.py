
import cv2

def decode_qr_from_image(image_path):
    image = cv2.imread(image_path)
    if image is None:
        return []

    detector = cv2.QRCodeDetector()
    data, points, _ = detector.detectAndDecode(image)

    results = []
    if data:
        results.append({
            "data": data,
            "rect": points.tolist() if points is not None else []
        })
    return results
