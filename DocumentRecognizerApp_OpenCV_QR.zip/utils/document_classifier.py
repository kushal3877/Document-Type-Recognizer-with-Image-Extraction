import re

def classify_document(text):
    text_lower = text.lower()

    if "government of india" in text_lower and re.search(r"\b\d{4}\s\d{4}\s\d{4}\b", text):
        aadhaar = re.search(r"(\d{4}\s\d{4}\s\d{4})", text).group(1)
        return "Aadhaar Card", {"Aadhaar Number": aadhaar}
    elif "income tax department" in text_lower and re.search(r"[A-Z]{5}\d{4}[A-Z]", text):
        pan = re.search(r"([A-Z]{5}\d{4}[A-Z])", text).group(1)
        return "PAN Card", {"PAN Number": pan}
    elif "invoice" in text_lower:
        invoice_no = re.search(r"invoice.*?(\d+)", text_lower)
        return "Invoice", {
            "Invoice Number": invoice_no.group(1) if invoice_no else "Not Found",
        }
    elif "purchase order" in text_lower:
        subtotal = re.search(r"subtotal\s*:?\s*(\d+\.\d{2})", text_lower)
        total = re.search(r"total\s*:?\s*(\d+\.\d{2})", text_lower)
        company = re.search(r"(?i)(?:company|name)\s*:?\s*([\w\s]+)", text_lower)
        return "Purchase Order", {
            "Subtotal": subtotal.group(1) if subtotal else "Not Found",
            "Total": total.group(1) if total else "Not Found",
            "Company": company.group(1).strip() if company else "Not Found"
        }

    return "Unknown Document", {}
