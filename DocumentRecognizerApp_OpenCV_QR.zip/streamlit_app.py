import streamlit as st

# ---------------- User Role & Login Setup ----------------
if 'authenticated' not in st.session_state:
    st.session_state.authenticated = False
if 'role' not in st.session_state:
    st.session_state.role = None

def login():
    st.title("🔐 Document Recognizer Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")

    if st.button("Login"):
        # Dummy credentials (extendable to DB/LDAP)
        credentials = {
            "admin": {"password": "admin123", "role": "Admin"},
            "analyst": {"password": "analyst123", "role": "Analyst"},
            "viewer": {"password": "viewer123", "role": "Viewer"}
        }

        if username in credentials and credentials[username]["password"] == password:
            st.session_state.authenticated = True
            st.session_state.role = credentials[username]["role"]
            st.success(f"Welcome {username}! Role: {st.session_state.role}")
            st.experimental_rerun()
        else:
            st.error("Invalid username or password.")

if not st.session_state.authenticated:
    login()
    st.stop()
else:
    st.sidebar.write(f"👤 Role: {st.session_state.role}")



import os
from utils.ocr_utils import translate_text

st.sidebar.header("Advanced Options")

# Feature: Translation
translate_option = st.sidebar.checkbox("Translate Extracted Text")
target_lang = st.sidebar.selectbox("Select Target Language", ["hi", "mr", "en"], index=0) if translate_option else None

# Feature: Smart Folder Scan
use_folder = False  # Disabled Tkinter-based folder scan for Streamlit compatibility
st.sidebar.info('To scan multiple files, upload them using the uploader below.')
if use_folder:
    root = tk.Tk()
    root.withdraw()
    st.sidebar.success(f"Folder selected: {folder_selected}")
    import glob
    import io
    uploaded_files = []
    for file_path in glob.glob(folder_selected + "/*"):
        with open(file_path, "rb") as f:
            file_bytes = io.BytesIO(f.read())
            file_bytes.name = os.path.basename(file_path)
            uploaded_files.append(file_bytes)

import streamlit as st
from utils.ocr_utils import translate_text_multilang

st.sidebar.header("Translation Options")
do_translate = st.sidebar.checkbox("Translate OCR Text")
target_lang = st.sidebar.selectbox("Target Language", ["hi", "gu"], index=0) if do_translate else None

import pandas as pd
from utils.ocr_utils import extract_text_from_file, extract_images_from_file, zip_images
from utils.document_classifier import classify_document
from PIL import Image

st.title("Document Type Recognizer with Image Extraction & Debug")

uploaded_files = st.file_uploader(
    "Upload file(s) (image/pdf/docx/xlsx)", 
    type=["jpg", "jpeg", "png", "pdf", "docx", "xlsx"], 
    accept_multiple_files=True
)

results = []

if uploaded_files:
    for uploaded_file in uploaded_files:
        st.header(f"📄 File: {uploaded_file.name}")
        with st.spinner("Processing..."):
            # Extract text
            text = extract_text_from_file(uploaded_file)
            doc_type, details = classify_document(text)

            # Feature 1: Show raw OCR text
            st.subheader("🔎 Raw Extracted Text (OCR Output):")
            st.text(text)
        if do_translate and target_lang:
            st.subheader("Translated Text:")
            st.text(translate_text_multilang(text, lang=target_lang))
    

            # Feature 2: Extract and display images
            st.subheader("🖼 Extracted Images:")
            images = extract_images_from_file(uploaded_file)
            if images:
                for i, img in enumerate(images):
                    st.image(img, caption=f"Extracted Image {i+1}", use_column_width=True)

                # Feature 2 (continued): Download images as ZIP
                zip_buffer = zip_images(images)
                st.download_button(
                    label="📥 Download All Extracted Images",
                    data=zip_buffer,
                    file_name=f"{uploaded_file.name}_images.zip",
                    mime="application/zip"
                )
            else:
                st.write("No images found in the file.")

            # Feature 3: Show classification
            st.subheader("📌 Detected Document Type:")
            st.write(doc_type)

            st.subheader("📋 Extracted Details:")
            for k, v in details.items():
                st.write(f"**{k}**: {v}")

            # Append to results for summary export
            results.append({
                "File Name": uploaded_file.name,
                "Document Type": doc_type,
                "Extracted Text": text,
                **details
            })

    # Feature 3: Export results
    if results:
        df = pd.DataFrame(results)
        st.subheader("📄 Summary Table")
        st.dataframe(df)

        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download Results as CSV",
            data=csv,
            file_name="document_results.csv",
            mime="text/csv"
        )

# Feature 4 (Signature/Stamp Detection) is pending model — can be added with ML/YOLO later
st.info("Feature 4 (Signature/Stamp Detection) will require ML model — currently placeholder.")



from utils.qr_utils import decode_qr_from_image


from utils.qr_utils import decode_qr_from_image

# ---------------- QR Code Section ----------------
st.header("📷 QR Code Detection (Aadhaar/PAN)")
uploaded_file = st.file_uploader("Upload Document (Image with QR)", type=["png", "jpg", "jpeg", "webp"])

if uploaded_file:
    file_path = f"temp_{uploaded_file.name}"
    with open(file_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    qr_results = decode_qr_from_image(file_path)
    if qr_results:
        for result in qr_results:
            st.success(f"✅ QR Code Detected: {result['data']}")
    else:
        st.warning("No QR Code detected in the uploaded image.")
